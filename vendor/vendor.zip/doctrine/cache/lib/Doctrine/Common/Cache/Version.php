<?php

namespace Doctrine\Common\Cache;

/**
 * @deprecated Deprecated without replacement in doctrine/cache 1.11. This class will be dropped in 2.0
 */
class Version
{
    public const VERSION = '1.9.0-DEV';
}
